/* 
    File: reqchannel.H

    Author: Murtaza H.
            Department of Computer Science
            Texas A&M University
    Date  : 2018/20/11

*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/
#include "MQRequestChannel.h"

#include <stdexcept>
#include <cstring>
#include <iostream>
#include <sys/msg.h>
#include <string>
#include <sys/ipc.h>
#include <unistd.h>
#include <sys/types.h>

/*--------------------------------------------------------------------------*/
/* MEMBER FUNCTIONS */
/*--------------------------------------------------------------------------*/

MQRequestChannel::MQRequestChannel(const string _name, const Side _side)
: RequestChannel(_name, _side) {
    int err;

    // CLIENT_SIDE
    string clientFilename = getIdentifier(CLIENT_SIDE);
    createFile(clientFilename);

    keyClient = fileKey(clientFilename);
    msgidClient = msgget(keyClient, IPC_CREAT | 0666);

    if(msgidClient == -1) {
        cout << "error client mssget" << endl;
    }

    // SERVER_SIDE
    string serverFilename = getIdentifier(SERVER_SIDE);
    createFile(serverFilename);

    keyServer = fileKey(serverFilename);
    msgidServer = msgget(keyServer, IPC_CREAT | 0666);

    if(msgidServer == -1) {
        cout << "error server mssget" << endl;
    }

    setmsgInfo(msgidClient);
    setmsgInfo(msgidServer);
}

MQRequestChannel::~MQRequestChannel() {
    int err;

    // DELETE client queue
    err = msgctl(msgidClient, IPC_RMID, nullptr);

    if(err != 0) {
        cout << "error mq destructor CLIENT" << endl;
    }

    // DELETE server queue
    err = msgctl(msgidServer, IPC_RMID, nullptr);

    if(err != 0) {
        cout << "error mq destructor SERVER" << endl;
    }
}

string MQRequestChannel::cread(void) {
    int err;

    char *buf = new char[MaxMsg];
    memset(buf, 0, MaxMsg);

    msg_buffer *msg = reinterpret_cast<msg_buffer *>(buf);

    do {
        int queue = (side == SERVER_SIDE) ? msgidServer : msgidClient;
        err = msgrcv(queue, buf, MaxMsg, 0, 0);

        if(err == -1) {
            if(errno != EINTR) {
                err = 0;
                break;
            } else {
                cout << "msgrcv failed" << endl;
                break;
            }
        }
    } while(err == -1);

    string payload = string(msg->payload);

    delete[] buf;
    return payload;
}

int MQRequestChannel::cwrite(string _msg) {
    int err;

    // get payload and validate its size
    const char *payload = _msg.c_str();
    size_t payloadLen = strlen(payload) + 1;

    if(payloadLen > QueueSize) {
        throw std::invalid_argument("message is too big");
    }

    // allocate message and clear it
    size_t bufLen = sizeof(msg_buffer) + payloadLen;

    char *buf = new char[bufLen];
    memset(buf, 0, bufLen);

    // fill in message and copy string
    msg_buffer *msg = reinterpret_cast<msg_buffer *>(buf);

    msg->type = 1;

    strncpy(msg->payload, payload, payloadLen);

    // send message
    int queue = (side == CLIENT_SIDE) ? msgidServer : msgidClient;
    err = msgsnd(queue, msg, payloadLen, 0);

    if(err == -1) {
        if(errno == EINVAL) {
            struct msqid_ds info;
            err = msgctl(queue, IPC_STAT, &info);

            if(err == -1 && (errno != EINVAL && errno != EIDRM)) {
                cout << "msgsnd failed (after msgctl)" << endl;
            }
        }
        else {
            cout << "msgsnd failed" << endl;
        }
    }

    delete[] buf;
    return payloadLen;
}

void MQRequestChannel::setmsgInfo(int msgid) {
    int err;

    struct msqid_ds info;

    err = msgctl(msgid, IPC_STAT, &info);

    if(err != 0) {
        cout << "error setmsginfo 1" << endl;
    }

    info.msg_qbytes = QueueSize;

    err = msgctl(msgid, IPC_SET, &info);

    if(err != 0) {
        cout << "error setmsginfo 2" << endl;
    }
}